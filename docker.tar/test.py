import sys
print ("Argument List:", str(sys.argv))